<!DOCTYPE TS><TS>
<defaultcodec>iso8859-1</defaultcodec>
<context>
    <name>Strings</name>
    <message>
        <source>LanguageName</source>
        <translation type="unfinished">Deutsch</translation>
    </message>
    <message>
        <source>ViPEC</source>
        <translation>ViPEC</translation>
    </message>
    <message>
        <source>ViPEC online help</source>
        <translation>ViPEC Online-Hilfe</translation>
    </message>
    <message>
        <source>Schematic name</source>
        <translation>Schematic Name</translation>
    </message>
    <message>
        <source>About ViPEC</source>
        <translation>über ViPEC</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>über Qt</translation>
    </message>
    <message>
        <source>Add new variable</source>
        <translation>Neue Variable einfügen</translation>
    </message>
    <message>
        <source>Modify frequency sweep</source>
        <translation>Ändern des Frequenz Sweeps</translation>
    </message>
    <message>
        <source>Modify grid</source>
        <translation>Ändern des Gitters</translation>
    </message>
    <message>
        <source>Modify Smith chart</source>
        <translation>Ändern des Smith-Diagramms</translation>
    </message>
    <message>
        <source>Change variable value</source>
        <translation type="unfinished">Ändern des Variablenwertes</translation>
    </message>
    <message>
        <source>Rename variable</source>
        <translation>Umbenennen der Variablen</translation>
    </message>
    <message>
        <source>Rename substrate</source>
        <translation>Umbenennen des Subtrats</translation>
    </message>
    <message>
        <source>Change dimension value</source>
        <translation>Ändern des Dimensionswertes</translation>
    </message>
    <message>
        <source>Edit component attributes</source>
        <translation>Ändern der Komponenteneigenschaft</translation>
    </message>
    <message>
        <source>Rename schematic</source>
        <translation>Umbenennen des Schematics</translation>
    </message>
    <message>
        <source>Add new graph</source>
        <translation>Eine neuen Graphen einfügen </translation>
    </message>
    <message>
        <source>Rename grid</source>
        <translation>Grid umbennenen</translation>
    </message>
    <message>
        <source>Delete grid</source>
        <translation>Grid löschen</translation>
    </message>
    <message>
        <source>Micro strip calculator</source>
        <translation>Microstripberechner</translation>
    </message>
    <message>
        <source>Change schematic size</source>
        <translation>Ändern der Größe des Schaltplans</translation>
    </message>
    <message>
        <source>Ready ...</source>
        <translation>Fertig ...</translation>
    </message>
    <message>
        <source>File saved</source>
        <translation>Datei gespeichert</translation>
    </message>
    <message>
        <source>File loaded</source>
        <translation>Datei geladen</translation>
    </message>
    <message>
        <source>Checking schematic %1 ...</source>
        <translation>Überprüfung des Schaltung %1 ...</translation>
    </message>
    <message>
        <source>Calculating response of schematic %1 ...</source>
        <translation>Berechnen der Antwort der Schaltung %1 ...</translation>
    </message>
    <message>
        <source>Frequency sweep done ...</source>
        <translation>Frequenzsweep beendet ...</translation>
    </message>
    <message>
        <source>All schematics passed checks ...</source>
        <translation>Alle Schaltungen haben einen korrekten Syntax ...</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <source>&amp;Open ...</source>
        <translation>&amp;Öffnen ...</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>S&amp;peichern</translation>
    </message>
    <message>
        <source>Save &amp;as ...</source>
        <translation>Speichern  &amp;unter ...</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Schliessen</translation>
    </message>
    <message>
        <source>&amp;New schematic ...</source>
        <translation>&amp;Neues Schaltbild ...</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation type="unfinished">&amp;Drucken</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished">Be&amp;enden</translation>
    </message>
    <message>
        <source>&amp;Controls</source>
        <translation>&amp;Einstellungen</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
    <message>
        <source>&amp;Index</source>
        <translation>&amp;Index</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation type="unfinished">&amp;über</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>über &amp;Qt</translation>
    </message>
    <message>
        <source>&amp;New item...</source>
        <translation>&amp;Neues Element ...</translation>
    </message>
    <message>
        <source>&amp;Modify item ...</source>
        <translation>Element &amp;ändern ...</translation>
    </message>
    <message>
        <source>&amp;Rename item ...</source>
        <translation>Element &amp;umbenennen ...</translation>
    </message>
    <message>
        <source>&amp;Delete item</source>
        <translation>Element &amp;löschen</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation type="unfinished">&amp;Werkzeuge</translation>
    </message>
    <message>
        <source>&amp;Micro strip calculator ...</source>
        <translation>&amp;Microstrip-Rechner ...</translation>
    </message>
    <message>
        <source>&amp;Tuner ...</source>
        <translation>&amp;Schieberegler ...</translation>
    </message>
    <message>
        <source>Your current changes are not saved! Do you wish to continue?</source>
        <translation>Ihre gegenwärtigen Einstellungen sind nicht gespeichert! Wollen Sie fortfahren?</translation>
    </message>
    <message>
        <source>Could not write file!</source>
        <translation>Kann die Datei nicht speichern!</translation>
    </message>
    <message>
        <source>Could not open file!</source>
        <translation type="unfinished">Kann die Datei nicht öffnen!</translation>
    </message>
    <message>
        <source>Please enter a name for the schematic</source>
        <translation type="unfinished">Bitte geben Sie den Namen des Schaltbilds ein</translation>
    </message>
    <message>
        <source>A schematic with that name already exists!</source>
        <translation>Ein Schaltbild mit diesem Namen existiert schon!</translation>
    </message>
    <message>
        <source>Please enter a name for the new variable</source>
        <translation>Geben Sie einen neuen Variablennamen ein</translation>
    </message>
    <message>
        <source>A variable with that name already exists!</source>
        <translation>Eine Variable mit diesem Namen existiert schon!</translation>
    </message>
    <message>
        <source>Please enter a value for the new variable</source>
        <translation>Geben Sie einen Wert für die neue Variable ein.</translation>
    </message>
    <message>
        <source>Please enter a new value for the variable named %1</source>
        <translation>Geben Sie einen neuen Wert für Variable %1 ein</translation>
    </message>
    <message>
        <source>Please enter a new name for the variable named %1</source>
        <translation>Geben Sie einen neuen Namen für die Variable %1</translation>
    </message>
    <message>
        <source>Do you really want to remove the variable named %1?</source>
        <translation>Wollen Sie die Variable %1 löschen?</translation>
    </message>
    <message>
        <source>Please enter a new name for the substrate named %1</source>
        <translation>Geben Sie einen neuen Namen für das Substrat %1</translation>
    </message>
    <message>
        <source>Do you really want to remove the substrate named %1?</source>
        <translation>Wollen Sie das Substrat mit dem Namen %1 löschen?</translation>
    </message>
    <message>
        <source>There are some floating nodes!</source>
        <translation>Es gibt nicht verknüpfte Knoten!</translation>
    </message>
    <message>
        <source>Some port nodes are shorted together!</source>
        <translation>Einige Knoten sind shorted together!</translation>
    </message>
    <message>
        <source>Please enter a new name for the schematic named %1</source>
        <translation>Geben Sie einen neuen Namen für das Schaltbild %1</translation>
    </message>
    <message>
        <source>Do you really want to remove the schematic named %1?</source>
        <translation>Wollen Sie Schaltbild %1 wirklich löschen?</translation>
    </message>
    <message>
        <source>Please enter a name for the graph</source>
        <translation>Geben Sie einen Namen für das Diagramm ein</translation>
    </message>
    <message>
        <source>Please enter a new name for the graph named %1</source>
        <translation>Geben Sie einen neuen Namen für Diagramm %1 ein</translation>
    </message>
    <message>
        <source>A graph with the name %1 already exists!</source>
        <translation>Ein Diagramm mit dem Namen %1 existiert schon!</translation>
    </message>
    <message>
        <source>Do you really want to remove the graph named %1?</source>
        <translation>Wollen Sie das Diagramm %1 löschen?</translation>
    </message>
    <message>
        <source>There are no schematics defined!</source>
        <translation>Es sind keine Schaltbilder definiert!</translation>
    </message>
    <message>
        <source>There are no range variables defined!</source>
        <translation>Es sind keine Wertebereiche für die Variablen definiert!</translation>
    </message>
    <message>
        <source>Circuit files (*.ckt)</source>
        <translation>Schaltungsdateien (*.ckt)</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation type="unfinished">&amp;Ja</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished">&amp;Abbrechen</translation>
    </message>
    <message>
        <source>&amp;Sweep</source>
        <translation type="unfinished">&amp;Frequenz abtasten</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Klein</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Mittel</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Groß</translation>
    </message>
    <message>
        <source>Navigation</source>
        <translation>Navigation</translation>
    </message>
    <message>
        <source>Graph name</source>
        <translation>Name des Diagramms</translation>
    </message>
    <message>
        <source>Graph type</source>
        <translation>Art des Diagramms</translation>
    </message>
    <message>
        <source>Rectangular</source>
        <translation>rechtwinklig</translation>
    </message>
    <message>
        <source>Smith chart</source>
        <translation>Smith-Diagramm</translation>
    </message>
    <message>
        <source>Table</source>
        <translation>Tabelle</translation>
    </message>
    <message>
        <source>Grid title</source>
        <translation>Titel des Gitters</translation>
    </message>
    <message>
        <source>Smith chart title</source>
        <translation>Titel des Smith-Diagramms</translation>
    </message>
    <message>
        <source>Minimum X axis value</source>
        <translation>Minimaler X-Wert</translation>
    </message>
    <message>
        <source>Maximum X axis value</source>
        <translation>Maximaler X-Wert</translation>
    </message>
    <message>
        <source>Number of X axis ticks</source>
        <translation>Anzahl Skalenstriche X-Achse</translation>
    </message>
    <message>
        <source>Minimum Y axis value</source>
        <translation>Minimaler Y-Wert</translation>
    </message>
    <message>
        <source>Maximum Y axis value</source>
        <translation>Maximaler Y-Wert</translation>
    </message>
    <message>
        <source>Number of Y axis ticks</source>
        <translation>Anzahl Skalenstriche Y-Achse</translation>
    </message>
    <message>
        <source>Port parameters</source>
        <translation>Torparameter</translation>
    </message>
    <message>
        <source>Linvill stability factor</source>
        <translation>Linvill-Stabilitätsparameter</translation>
    </message>
    <message>
        <source>Stern stability factor</source>
        <translation>Stern-Stabilitätsparameter</translation>
    </message>
    <message>
        <source>S-Parameters</source>
        <translation>S-Parameter</translation>
    </message>
    <message>
        <source>Y-Parameters</source>
        <translation>Y-Parameter</translation>
    </message>
    <message>
        <source>Z-Parameters</source>
        <translation>Z-Parameter</translation>
    </message>
    <message>
        <source>Group delay</source>
        <translation>Gruppenlaufzeit</translation>
    </message>
    <message>
        <source>Measurement type</source>
        <translation>Meßart</translation>
    </message>
    <message>
        <source>Measurement</source>
        <translation>Messung</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Real</source>
        <translation>Realteil</translation>
    </message>
    <message>
        <source>Imag</source>
        <translation>Imaginärteil</translation>
    </message>
    <message>
        <source>Mag</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Ang</source>
        <translation>Winkel</translation>
    </message>
    <message>
        <source>Results in DB</source>
        <translation>Ergebnis in dB</translation>
    </message>
    <message>
        <source>Data source</source>
        <translation>Datenquelle</translation>
    </message>
    <message>
        <source>To port</source>
        <translation>Zum Tor</translation>
    </message>
    <message>
        <source>From port</source>
        <translation>Vom Tor</translation>
    </message>
    <message>
        <source>X-axis tracks project frequency</source>
        <translation>X-Achse folgt Projekt-Frequenz</translation>
    </message>
    <message>
        <source>Auto sweep</source>
        <translation>Interaktive Parameterabstimmung</translation>
    </message>
    <message>
        <source>Substrate name</source>
        <translation>Substratname</translation>
    </message>
    <message>
        <source>Substrate type</source>
        <translation>Substrattyp</translation>
    </message>
    <message>
        <source>Microstrip</source>
        <translation>Microstrip</translation>
    </message>
    <message>
        <source>Stripline</source>
        <translation>Koaxialröhre</translation>
    </message>
    <message>
        <source>Dielectric constant (Er)</source>
        <translation>Dielektrizitätskonstante(Er)</translation>
    </message>
    <message>
        <source>Height (H)</source>
        <translation>Höhe (H)</translation>
    </message>
    <message>
        <source>Conductor thickness (T)</source>
        <translation>Leiterdicke (T)</translation>
    </message>
    <message>
        <source>Loss tangent (rho)</source>
        <translation>Verlustfaktor (rho)</translation>
    </message>
    <message>
        <source>Schematic size</source>
        <translation>Schaltbildgröße</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Datei Öffnen</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation>Datei speichern</translation>
    </message>
    <message>
        <source>New schematic</source>
        <translation>Neues Schaltbild</translation>
    </message>
    <message>
        <source>Place symbol</source>
        <translation>Plaziere Element</translation>
    </message>
    <message>
        <source>Connect symbols</source>
        <translation>Verbinde Knoten</translation>
    </message>
    <message>
        <source>Toggle grid</source>
        <translation>Ein- Ausschalten des Gitters</translation>
    </message>
    <message>
        <source>Toggle component text</source>
        <translation>Umschalten des Komponententext</translation>
    </message>
    <message>
        <source>Rotate symbol</source>
        <translation>Symbol rotieren</translation>
    </message>
    <message>
        <source>Sweep</source>
        <translation>Frequenz Abtasten</translation>
    </message>
    <message>
        <source>Delete symbol</source>
        <translation>Symbol löschen</translation>
    </message>
    <message>
        <source>Port components</source>
        <translation>Tore, Masse</translation>
    </message>
    <message>
        <source>Block components</source>
        <translation>Schaltblöcke</translation>
    </message>
    <message>
        <source>Lumped components</source>
        <translation>Einfache Elemente L,R,C</translation>
    </message>
    <message>
        <source>Transmission line components</source>
        <translation>Leitungskomponenten</translation>
    </message>
    <message>
        <source>VCCS</source>
        <translation>VCCS</translation>
    </message>
    <message>
        <source>GYRATOR</source>
        <translation>GYRATOR</translation>
    </message>
    <message>
        <source>RESISTOR</source>
        <translation>WIDERSTAND</translation>
    </message>
    <message>
        <source>CAPACITOR</source>
        <translation>KONDENSATOR</translation>
    </message>
    <message>
        <source>INDUCTOR</source>
        <translation>SPULE</translation>
    </message>
    <message>
        <source>INDUCTORQ</source>
        <translation>SPULE Q</translation>
    </message>
    <message>
        <source>TRANSISTOR</source>
        <translation>TRANSISTOR</translation>
    </message>
    <message>
        <source>TLIN2PORT</source>
        <translation>2TOR-KOAXIALLEITER</translation>
    </message>
    <message>
        <source>TLIN4PORT</source>
        <translation>4TOR-KOAXIALLEITER</translation>
    </message>
    <message>
        <source>TLINPHYSICAL</source>
        <translation>KOAXIALLEITERPHYSIKALISCH</translation>
    </message>
    <message>
        <source>CLIN</source>
        <translation>INTERDIGITALLEITER</translation>
    </message>
    <message>
        <source>GND</source>
        <translation>MASSE</translation>
    </message>
    <message>
        <source>PORT</source>
        <translation>1-TOR</translation>
    </message>
    <message>
        <source>BLOCK1PORT</source>
        <translation>BLOCK1TOR</translation>
    </message>
    <message>
        <source>BLOCK2PORT</source>
        <translation>BLOCK2TOR</translation>
    </message>
    <message>
        <source>Schematics</source>
        <translation>Schaltbild</translation>
    </message>
    <message>
        <source>Project frequencies</source>
        <translation>Projekt-Frequenzen</translation>
    </message>
    <message>
        <source>Graphs</source>
        <translation>Diagramme</translation>
    </message>
    <message>
        <source>Variables</source>
        <translation>Variablen</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Einheiten</translation>
    </message>
    <message>
        <source>Substrate definitions</source>
        <translation>Substratdefinitionen</translation>
    </message>
    <message>
        <source>Data files</source>
        <translation>Parameterdateien</translation>
    </message>
    <message>
        <source>noname.ckt</source>
        <translation>unbenannt.ckt</translation>
    </message>
    <message>
        <source>Sweep type</source>
        <translation>Frequenzabtastart</translation>
    </message>
    <message>
        <source>Linear</source>
        <translation>linear</translation>
    </message>
    <message>
        <source>Logarithmic</source>
        <translation>logarithmisch</translation>
    </message>
    <message>
        <source>Start frequency</source>
        <translation>Startfrequenz</translation>
    </message>
    <message>
        <source>Stop frequency</source>
        <translation>Stopfrequenz</translation>
    </message>
    <message>
        <source>Number of points</source>
        <translation>Anzahl der Punkte</translation>
    </message>
    <message>
        <source>Frequency</source>
        <translation>Frequenz</translation>
    </message>
    <message>
        <source>Resistance</source>
        <translation>Widerstand</translation>
    </message>
    <message>
        <source>Capacitance</source>
        <translation>Kapazität</translation>
    </message>
    <message>
        <source>Inductance</source>
        <translation>Induktivität</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Winkel</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Länge</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Zeit</translation>
    </message>
    <message>
        <source>Impedance</source>
        <translation>Impedanz</translation>
    </message>
    <message>
        <source>Odd mode impedance</source>
        <translation>Gegentaktimpedanz</translation>
    </message>
    <message>
        <source>Even mode impedance</source>
        <translation>Gleichtaktimpedanz</translation>
    </message>
    <message>
        <source>Electrical length in degrees</source>
        <translation>Elektrische Länge in Grad</translation>
    </message>
    <message>
        <source>Frequency at which electrical length is defined</source>
        <translation>Frequenz, die die elektrische Länge definiert</translation>
    </message>
    <message>
        <source>Substrate</source>
        <translation>Substrat</translation>
    </message>
    <message>
        <source>Port impedance</source>
        <translation>Impedanz des Tors</translation>
    </message>
    <message>
        <source>Block name</source>
        <translation>Name des Blockelements</translation>
    </message>
    <message>
        <source>Quality factor</source>
        <translation>Güte</translation>
    </message>
    <message>
        <source>Trans conductance</source>
        <translation>Transkonduktanz</translation>
    </message>
    <message>
        <source>Gyrator factor</source>
        <translation>Gyratorfaktor</translation>
    </message>
    <message>
        <source>Line width</source>
        <translation>Leitungsbreite</translation>
    </message>
    <message>
        <source>Line length</source>
        <translation>Leitungslänge</translation>
    </message>
    <message>
        <source>Circuit tuner</source>
        <translation>Schaltungsabstimmer</translation>
    </message>
    <message>
        <source>Define substrate</source>
        <translation>Definition des Substrats </translation>
    </message>
    <message>
        <source>Missing attribute value in circuit %1!</source>
        <translation>Ein Elementattribut in Schaltbild %1 fehlt!</translation>
    </message>
    <message>
        <source>Undefined variable in cicuit %1!</source>
        <translation>Undefinierte Variable in Schaltbild %1!</translation>
    </message>
    <message>
        <source>Variable used in circuit %1 has no value!</source>
        <translation>Benutzte Variable in Schaltbild %1 hat keinen Wert!</translation>
    </message>
    <message>
        <source>Undefined substrate in circuit %1!</source>
        <translation>Undefiniertes Substrat in Schaltung %1!</translation>
    </message>
    <message>
        <source>Unknown exception!!!</source>
        <translation>Unbekannter Ausnahmefehler!!!</translation>
    </message>
    <message>
        <source>The output definitions contains an invalid circuit name!</source>
        <translation>Die Definition der Ausgabeparameter enthält einen ungültigen Schaltbildnamen!</translation>
    </message>
    <message>
        <source>Stability factors are only defined for 2 port circuits!</source>
        <translation>Stabilitätsfaktoren sind nur für 2-Tore definiert!</translation>
    </message>
    <message>
        <source>Singular matrix - no solution possible!</source>
        <translation>Singuläre Martix - keine Lösung möglich!</translation>
    </message>
    <message>
        <source>The number of ports are not matched!</source>
        <translation>Die Anzahl Tore passen nicht!</translation>
    </message>
    <message>
        <source>Undefined block in circuit %1!</source>
        <translation>Undefinierter Schaltungsblock in Schaltbild %1!</translation>
    </message>
    <message>
        <source>Sweep frequency beyond limits of block data in circuit %1</source>
        <translation>Die Abtastfrequenz überschreitet die Grenzen des Schaltungsblock in Schaltbild %1</translation>
    </message>
    <message>
        <source>Parameter files (*.?2p)</source>
        <translation>Parameterdatei (*.?2p)</translation>
    </message>
    <message>
        <source>Output parameter definition</source>
        <translation>Definition der Ausgabeparameter</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Betrachten</translation>
    </message>
    <message>
        <source>&amp;Refresh</source>
        <translation>Auf&amp;frischen</translation>
    </message>
    <message>
        <source>&amp;Markers</source>
        <translation>&amp;Marke</translation>
    </message>
    <message>
        <source>&amp;Toggle</source>
        <translation>&amp;Umschalten</translation>
    </message>
    <message>
        <source>&amp;Fonts</source>
        <translation>&amp;Schriftarten</translation>
    </message>
    <message>
        <source>&amp;Title font ...</source>
        <translation>&amp;Titel Schriftart ...</translation>
    </message>
    <message>
        <source>&amp;Label font ...</source>
        <translation>&amp;Beschriftung Schriftart ...</translation>
    </message>
    <message>
        <source>&amp;Dielectric constant</source>
        <translation>&amp;Dielektrizitätskonstante</translation>
    </message>
    <message>
        <source>F&amp;requency</source>
        <translation>F&amp;requenz</translation>
    </message>
    <message>
        <source>Line &amp;length</source>
        <translation type="unfinished">&amp;Leitungslänge</translation>
    </message>
    <message>
        <source>Line &amp;width</source>
        <translation>Leiter&amp;breite</translation>
    </message>
    <message>
        <source>Elec&amp;trical length</source>
        <translation type="unfinished">&amp;Elektrische Länge</translation>
    </message>
    <message>
        <source>Line &amp;impedance</source>
        <translation>&amp;Leitungswellenwiderstand</translation>
    </message>
    <message>
        <source>&amp;Electrical</source>
        <translation>&amp;elektrisch</translation>
    </message>
    <message>
        <source>&amp;Physical</source>
        <translation>&amp;physikalisch</translation>
    </message>
    <message>
        <source>degrees</source>
        <translation>Grad</translation>
    </message>
    <message>
        <source>impedance</source>
        <translation>Impedanz</translation>
    </message>
    <message>
        <source>&amp;Substrate height</source>
        <translation>&amp;Substrathöhe</translation>
    </message>
    <message>
        <source>Select Language</source>
        <translation>Sprache auswählen</translation>
    </message>
    <message>
        <source>&amp;Setup</source>
        <translation>&amp;Einstellungen</translation>
    </message>
    <message>
        <source>&amp;Language</source>
        <translation>&amp;Sprache</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <source>New settings will take effect when ViPEC is restarted</source>
        <translation>Die neuen Einstellungen werden nach einem Neustart von ViPEC aktiv</translation>
    </message>
    <message>
        <source>INDUCTORM</source>
        <translation>INDUKTIVITÄT M</translation>
    </message>
    <message>
        <source>Coupling factor</source>
        <translation>Koppelfaktor</translation>
    </message>
    <message>
        <source>CAPACITORQ</source>
        <translation></translation>
    </message>
    <message>
        <source>Primary inductance (L1)</source>
        <translation></translation>
    </message>
    <message>
        <source>Secondary inductance (L2)</source>
        <translation></translation>
    </message>
</context>
</TS>
