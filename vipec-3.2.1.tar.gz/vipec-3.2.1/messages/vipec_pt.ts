<!DOCTYPE TS><TS>
<defaultcodec>iso8859-1</defaultcodec>
<context>
    <name>Strings</name>
    <message>
        <source>LanguageName</source>
        <translation type="unfinished">Portugese</translation>
    </message>
    <message>
        <source>ViPEC</source>
        <translation>ViPEC</translation>
    </message>
    <message>
        <source>ViPEC online help</source>
        <translation>Ajuda em linha ViPEC</translation>
    </message>
    <message>
        <source>Schematic name</source>
        <translation>Nome do esquemático</translation>
    </message>
    <message>
        <source>About ViPEC</source>
        <translation>Sobre o ViPEC</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Sobre a Qt</translation>
    </message>
    <message>
        <source>Add new variable</source>
        <translation>Adicionar nova variável</translation>
    </message>
    <message>
        <source>Modify frequency sweep</source>
        <translation>Mudar gama de frequências de varredura</translation>
    </message>
    <message>
        <source>Modify grid</source>
        <translation>Mudar a grelha</translation>
    </message>
    <message>
        <source>Modify Smith chart</source>
        <translation>Mudar a carta de Smith</translation>
    </message>
    <message>
        <source>Change variable value</source>
        <translation>Mudar o valor da variável</translation>
    </message>
    <message>
        <source>Rename variable</source>
        <translation>Renomear variável</translation>
    </message>
    <message>
        <source>Rename substrate</source>
        <translation>Renomear o substrato</translation>
    </message>
    <message>
        <source>Change dimension value</source>
        <translation>Mudar o valor das dimensões</translation>
    </message>
    <message>
        <source>Edit component attributes</source>
        <translation type="unfinished">Editor de atributos do componente</translation>
    </message>
    <message>
        <source>Rename schematic</source>
        <translation>Renomear o esquemático</translation>
    </message>
    <message>
        <source>Add new graph</source>
        <translation>Adicionar um novo gráfico</translation>
    </message>
    <message>
        <source>Rename grid</source>
        <translation>Renomear a grelha</translation>
    </message>
    <message>
        <source>Delete grid</source>
        <translation>Suprimir grelha</translation>
    </message>
    <message>
        <source>Micro strip calculator</source>
        <translation>Calculador da linha Microstrip</translation>
    </message>
    <message>
        <source>Change schematic size</source>
        <translation>Mudar o tamanho do esquemático</translation>
    </message>
    <message>
        <source>Ready ...</source>
        <translation>Pronto ...</translation>
    </message>
    <message>
        <source>File saved</source>
        <translation>Ficheiro gravado</translation>
    </message>
    <message>
        <source>File loaded</source>
        <translation>Ficheiro carregado</translation>
    </message>
    <message>
        <source>Checking schematic %1 ...</source>
        <translation>Verificação do esquemático %1 ...</translation>
    </message>
    <message>
        <source>Calculating response of schematic %1 ...</source>
        <translation>Cálculo da resposta do esquemático %1 ...</translation>
    </message>
    <message>
        <source>Frequency sweep done ...</source>
        <translation>Percorrida a gama de frequências de varredura...</translation>
    </message>
    <message>
        <source>All schematics passed checks ...</source>
        <translation>Todos os esquemáticos estão correctos ...</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Ficheiro</translation>
    </message>
    <message>
        <source>&amp;Open ...</source>
        <translation>&amp;Abrir ...</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Gravar</translation>
    </message>
    <message>
        <source>Save &amp;as ...</source>
        <translation>Gravar &amp;como ...</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <source>&amp;New schematic ...</source>
        <translation>&amp;Novo esquemático ...</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation>&amp;Imprimir</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Sair</translation>
    </message>
    <message>
        <source>&amp;Controls</source>
        <translation>&amp;Controlos</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <source>&amp;Index</source>
        <translation>&amp;Índice</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;Sobre</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Sobre a &amp;Qt</translation>
    </message>
    <message>
        <source>&amp;New item...</source>
        <translation>&amp;Novo elemento ...</translation>
    </message>
    <message>
        <source>&amp;Modify item ...</source>
        <translation>&amp;Modificar elemento ...</translation>
    </message>
    <message>
        <source>&amp;Rename item ...</source>
        <translation>&amp;Renomear elemento ...</translation>
    </message>
    <message>
        <source>&amp;Delete item</source>
        <translation>&amp;Suprimir elemento</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>&amp;Ferramentas</translation>
    </message>
    <message>
        <source>&amp;Micro strip calculator ...</source>
        <translation>&amp;Calculador da linha microstrip ...</translation>
    </message>
    <message>
        <source>&amp;Tuner ...</source>
        <translation>&amp;Sintonizar ...</translation>
    </message>
    <message>
        <source>Your current changes are not saved! Do you wish to continue?</source>
        <translation>As suas modificações não estão gravadas! Quer continuar?</translation>
    </message>
    <message>
        <source>Could not write file!</source>
        <translation>Não foi possível escrever ficheiro!</translation>
    </message>
    <message>
        <source>Could not open file!</source>
        <translation>Não foi possível abrir ficheiro!</translation>
    </message>
    <message>
        <source>Please enter a name for the schematic</source>
        <translation>Por favor, insira um nome para o esquemático</translation>
    </message>
    <message>
        <source>A schematic with that name already exists!</source>
        <translation>Já existe um esquemático com esse nome!</translation>
    </message>
    <message>
        <source>Please enter a name for the new variable</source>
        <translation>Insira um nome para a nova variável</translation>
    </message>
    <message>
        <source>A variable with that name already exists!</source>
        <translation>Já existe uma variável com esse nome!</translation>
    </message>
    <message>
        <source>Please enter a value for the new variable</source>
        <translation>Insira um valor para a nova variável</translation>
    </message>
    <message>
        <source>Please enter a new value for the variable named %1</source>
        <translation>Insira um novo valor para a variável %1</translation>
    </message>
    <message>
        <source>Please enter a new name for the variable named %1</source>
        <translation>Insira um novo nome para a variável %1</translation>
    </message>
    <message>
        <source>Do you really want to remove the variable named %1?</source>
        <translation>Quer realmente apagar a variável de nome %1 ?</translation>
    </message>
    <message>
        <source>Please enter a new name for the substrate named %1</source>
        <translation>Insira um novo nome para o substrato %1</translation>
    </message>
    <message>
        <source>Do you really want to remove the substrate named %1?</source>
        <translation>Quer realmente apagar o substrato de nome %1 ?</translation>
    </message>
    <message>
        <source>There are some floating nodes!</source>
        <translation>Existem nodos flutuantes no circuito!</translation>
    </message>
    <message>
        <source>Some port nodes are shorted together!</source>
        <translation>Alguns dos nodos do porto estão ligados entre si!</translation>
    </message>
    <message>
        <source>Please enter a new name for the schematic named %1</source>
        <translation>Insira um novo nome para o esquemático %1</translation>
    </message>
    <message>
        <source>Do you really want to remove the schematic named %1?</source>
        <translation>Quer realmente apagar o esquemático de nome %1 ?</translation>
    </message>
    <message>
        <source>Please enter a name for the graph</source>
        <translation>Insira um nome para o gráfico</translation>
    </message>
    <message>
        <source>Please enter a new name for the graph named %1</source>
        <translation>Insira um novo nome para o gráfico %1</translation>
    </message>
    <message>
        <source>A graph with the name %1 already exists!</source>
        <translation>Já existe um gráfico com nome %1!</translation>
    </message>
    <message>
        <source>Do you really want to remove the graph named %1?</source>
        <translation>Quer realmente apagar o gráfico de nome %1 ?</translation>
    </message>
    <message>
        <source>There are no schematics defined!</source>
        <translation>Não está definido nenhum esquemático !</translation>
    </message>
    <message>
        <source>There are no range variables defined!</source>
        <translation>Não está definida nenhuma variável de variação!</translation>
    </message>
    <message>
        <source>Circuit files (*.ckt)</source>
        <translation>Ficheiros de circuito (*.ckt)</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Sim</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>&amp;Sweep</source>
        <translation>&amp;Varredura</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Pequeno</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Médio</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Grande</translation>
    </message>
    <message>
        <source>Navigation</source>
        <translation>Navigação</translation>
    </message>
    <message>
        <source>Graph name</source>
        <translation>Nome do gráfico</translation>
    </message>
    <message>
        <source>Graph type</source>
        <translation>Tipo do gráfico</translation>
    </message>
    <message>
        <source>Rectangular</source>
        <translation>Retangular</translation>
    </message>
    <message>
        <source>Smith chart</source>
        <translation>Carta de Smith</translation>
    </message>
    <message>
        <source>Table</source>
        <translation>Tabela</translation>
    </message>
    <message>
        <source>Grid title</source>
        <translation>Título da grelha</translation>
    </message>
    <message>
        <source>Smith chart title</source>
        <translation>Título da carta de Smith</translation>
    </message>
    <message>
        <source>Minimum X axis value</source>
        <translation>Valor mínimo do eixo X</translation>
    </message>
    <message>
        <source>Maximum X axis value</source>
        <translation>Valor máximo do eixo X</translation>
    </message>
    <message>
        <source>Number of X axis ticks</source>
        <translation>Número de marcas sobre o eixo X</translation>
    </message>
    <message>
        <source>Minimum Y axis value</source>
        <translation>Valor mínimo do eixo Y</translation>
    </message>
    <message>
        <source>Maximum Y axis value</source>
        <translation>Valor máximo do eixo Y</translation>
    </message>
    <message>
        <source>Number of Y axis ticks</source>
        <translation>Número de marcas sobre o eixo Y</translation>
    </message>
    <message>
        <source>Port parameters</source>
        <translation>Parâmetros do porto</translation>
    </message>
    <message>
        <source>Linvill stability factor</source>
        <translation>Factor de estabilidade de Linvill</translation>
    </message>
    <message>
        <source>Stern stability factor</source>
        <translation>Factor de estabilidade de Stern</translation>
    </message>
    <message>
        <source>S-Parameters</source>
        <translation>Parâmetros S</translation>
    </message>
    <message>
        <source>Y-Parameters</source>
        <translation>Parâmetros Y</translation>
    </message>
    <message>
        <source>Z-Parameters</source>
        <translation>Parâmetros Z</translation>
    </message>
    <message>
        <source>Group delay</source>
        <translation>Atraso de grupo</translation>
    </message>
    <message>
        <source>Measurement type</source>
        <translation>Tipo de medida</translation>
    </message>
    <message>
        <source>Measurement</source>
        <translation>Medida</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <source>Real</source>
        <translation>Real</translation>
    </message>
    <message>
        <source>Imag</source>
        <translation>Imag</translation>
    </message>
    <message>
        <source>Mag</source>
        <translation>Mod</translation>
    </message>
    <message>
        <source>Ang</source>
        <translation>Arg</translation>
    </message>
    <message>
        <source>Results in DB</source>
        <translation>Resultados em dB</translation>
    </message>
    <message>
        <source>Data source</source>
        <translation>Ficheiro fonte</translation>
    </message>
    <message>
        <source>To port</source>
        <translation>Em direcção ao porto</translation>
    </message>
    <message>
        <source>From port</source>
        <translation>Do porto</translation>
    </message>
    <message>
        <source>X-axis tracks project frequency</source>
        <translation>O eixo X segue a frequência de projecto</translation>
    </message>
    <message>
        <source>Auto sweep</source>
        <translation>Varredura automática</translation>
    </message>
    <message>
        <source>Substrate name</source>
        <translation>Nome do substrato</translation>
    </message>
    <message>
        <source>Substrate type</source>
        <translation>Tipo do substrato</translation>
    </message>
    <message>
        <source>Microstrip</source>
        <translation>Microstrip</translation>
    </message>
    <message>
        <source>Stripline</source>
        <translation>Linha strip</translation>
    </message>
    <message>
        <source>Dielectric constant (Er)</source>
        <translation>Constante dieléctrica (Er)</translation>
    </message>
    <message>
        <source>Height (H)</source>
        <translation>Altura (H)</translation>
    </message>
    <message>
        <source>Conductor thickness (T)</source>
        <translation>Espessura do condutor (T)</translation>
    </message>
    <message>
        <source>Loss tangent (rho)</source>
        <translation>Tangente de perdas (rho)</translation>
    </message>
    <message>
        <source>Schematic size</source>
        <translation>Tamanho do esquemático</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Abrir o ficheiro</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation>Gravar o ficheiro</translation>
    </message>
    <message>
        <source>New schematic</source>
        <translation>Novo esquemático</translation>
    </message>
    <message>
        <source>Place symbol</source>
        <translation>Colocar símbolo</translation>
    </message>
    <message>
        <source>Connect symbols</source>
        <translation>Ligar os símbolos</translation>
    </message>
    <message>
        <source>Toggle grid</source>
        <translation>Mostrar grelha</translation>
    </message>
    <message>
        <source>Toggle component text</source>
        <translation>Mostrar o texto do componente</translation>
    </message>
    <message>
        <source>Rotate symbol</source>
        <translation>Rodar o símbolo</translation>
    </message>
    <message>
        <source>Sweep</source>
        <translation>Varredura</translation>
    </message>
    <message>
        <source>Delete symbol</source>
        <translation>Suprimir o símbolo</translation>
    </message>
    <message>
        <source>Port components</source>
        <translation>Componentes do porto</translation>
    </message>
    <message>
        <source>Block components</source>
        <translation>Componentes do Bloco</translation>
    </message>
    <message>
        <source>Lumped components</source>
        <translation>Componentes distribuídos</translation>
    </message>
    <message>
        <source>Transmission line components</source>
        <translation>Componentes da linha de transmissão</translation>
    </message>
    <message>
        <source>VCCS</source>
        <translation>VCCS</translation>
    </message>
    <message>
        <source>GYRATOR</source>
        <translation>GIRATOR</translation>
    </message>
    <message>
        <source>RESISTOR</source>
        <translation>RESISTENCIA</translation>
    </message>
    <message>
        <source>CAPACITOR</source>
        <translation>CONDENSADOR</translation>
    </message>
    <message>
        <source>INDUCTOR</source>
        <translation>INDUTANCIA</translation>
    </message>
    <message>
        <source>INDUCTORQ</source>
        <translation>INDUTANCIAQ</translation>
    </message>
    <message>
        <source>TRANSISTOR</source>
        <translation>TRANSISTOR</translation>
    </message>
    <message>
        <source>TLIN2PORT</source>
        <translation>TLIN2PORT</translation>
    </message>
    <message>
        <source>TLIN4PORT</source>
        <translation>TLIN4PORT</translation>
    </message>
    <message>
        <source>TLINPHYSICAL</source>
        <translation>TLINPHYSICAL</translation>
    </message>
    <message>
        <source>CLIN</source>
        <translation>CLIN</translation>
    </message>
    <message>
        <source>GND</source>
        <translation>GND</translation>
    </message>
    <message>
        <source>PORT</source>
        <translation>PORT</translation>
    </message>
    <message>
        <source>BLOCK1PORT</source>
        <translation>BLOC1PORT</translation>
    </message>
    <message>
        <source>BLOCK2PORT</source>
        <translation>BLOC2PORT</translation>
    </message>
    <message>
        <source>Schematics</source>
        <translation>Esquemáticos</translation>
    </message>
    <message>
        <source>Project frequencies</source>
        <translation>Frequências do projecto</translation>
    </message>
    <message>
        <source>Graphs</source>
        <translation>Gráficos</translation>
    </message>
    <message>
        <source>Variables</source>
        <translation>Variáveis</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <source>Substrate definitions</source>
        <translation>Definições do substrato</translation>
    </message>
    <message>
        <source>Data files</source>
        <translation>Ficheiros de dados</translation>
    </message>
    <message>
        <source>noname.ckt</source>
        <translation>noname.ckt</translation>
    </message>
    <message>
        <source>Sweep type</source>
        <translation>Tipo de varredura</translation>
    </message>
    <message>
        <source>Linear</source>
        <translation>Linear</translation>
    </message>
    <message>
        <source>Logarithmic</source>
        <translation>Logaritmico</translation>
    </message>
    <message>
        <source>Start frequency</source>
        <translation>Frequência Inicial</translation>
    </message>
    <message>
        <source>Stop frequency</source>
        <translation>Frequência Final</translation>
    </message>
    <message>
        <source>Number of points</source>
        <translation>Número de pontos</translation>
    </message>
    <message>
        <source>Frequency</source>
        <translation>Frequência</translation>
    </message>
    <message>
        <source>Resistance</source>
        <translation>Resistência</translation>
    </message>
    <message>
        <source>Capacitance</source>
        <translation>Capacitância</translation>
    </message>
    <message>
        <source>Inductance</source>
        <translation>Indutância</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Angulo</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Comprimento</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Tempo</translation>
    </message>
    <message>
        <source>Impedance</source>
        <translation>Impedância</translation>
    </message>
    <message>
        <source>Odd mode impedance</source>
        <translation>Impedância de modo impar</translation>
    </message>
    <message>
        <source>Even mode impedance</source>
        <translation>Impedância de modo par</translation>
    </message>
    <message>
        <source>Electrical length in degrees</source>
        <translation>Comprimento eléctrico em graus</translation>
    </message>
    <message>
        <source>Frequency at which electrical length is defined</source>
        <translation>Frequência na qual o comprimento eléctrico é definido</translation>
    </message>
    <message>
        <source>Substrate</source>
        <translation>Substrato</translation>
    </message>
    <message>
        <source>Port impedance</source>
        <translation>Impedância do porto</translation>
    </message>
    <message>
        <source>Block name</source>
        <translation>Nome do bloco</translation>
    </message>
    <message>
        <source>Quality factor</source>
        <translation>Factor de qualidade</translation>
    </message>
    <message>
        <source>Trans conductance</source>
        <translation>Transcondutancia</translation>
    </message>
    <message>
        <source>Gyrator factor</source>
        <translation type="unfinished">Factor de giro</translation>
    </message>
    <message>
        <source>Line width</source>
        <translation>Largura da Linha</translation>
    </message>
    <message>
        <source>Line length</source>
        <translation>Comprimento da Linha</translation>
    </message>
    <message>
        <source>Circuit tuner</source>
        <translation>Sintonizador do Circuito</translation>
    </message>
    <message>
        <source>Define substrate</source>
        <translation>Definir o Substrato</translation>
    </message>
    <message>
        <source>Missing attribute value in circuit %1!</source>
        <translation>Falta um valor de parâmetro no circuito %1 !</translation>
    </message>
    <message>
        <source>Undefined variable in cicuit %1!</source>
        <translation>Falta definir uma variável no circuito %1 !</translation>
    </message>
    <message>
        <source>Variable used in circuit %1 has no value!</source>
        <translation>A variável utilizada no circuito %1 não tem valor atribuído!</translation>
    </message>
    <message>
        <source>Undefined substrate in circuit %1!</source>
        <translation>Substrato não definido no circuito %1 !</translation>
    </message>
    <message>
        <source>Unknown exception!!!</source>
        <translation>Excepção desconhecida!</translation>
    </message>
    <message>
        <source>The output definitions contains an invalid circuit name!</source>
        <translation>As definições de saída contêm um nome de circuito inválido !</translation>
    </message>
    <message>
        <source>Stability factors are only defined for 2 port circuits!</source>
        <translation>Os factores de estabilidade são apenas definidos para circuitos de 2 portos!</translation>
    </message>
    <message>
        <source>Singular matrix - no solution possible!</source>
        <translation>Matriz singular - não é possível obter solução!</translation>
    </message>
    <message>
        <source>The number of ports are not matched!</source>
        <translation>Os número dos portos não se correspondem!</translation>
    </message>
    <message>
        <source>Undefined block in circuit %1!</source>
        <translation>Bloco não definido no circuito %1 !</translation>
    </message>
    <message>
        <source>Sweep frequency beyond limits of block data in circuit %1</source>
        <translation>A frequência de varredura está fora dos limites de dados do bloco no circuito %1</translation>
    </message>
    <message>
        <source>Parameter files (*.?2p)</source>
        <translation>Ficheiros de parâmetro (*.?2p)</translation>
    </message>
    <message>
        <source>Output parameter definition</source>
        <translation>Definição do parâmetro de saída</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Visualisar</translation>
    </message>
    <message>
        <source>&amp;Refresh</source>
        <translation>&amp;Refrescar</translation>
    </message>
    <message>
        <source>&amp;Markers</source>
        <translation>&amp;Marcadores</translation>
    </message>
    <message>
        <source>&amp;Toggle</source>
        <translation>&amp;Modificar</translation>
    </message>
    <message>
        <source>&amp;Fonts</source>
        <translation>&amp;Fonts</translation>
    </message>
    <message>
        <source>&amp;Title font ...</source>
        <translation>&amp;Tipo de caractere do título ...</translation>
    </message>
    <message>
        <source>&amp;Label font ...</source>
        <translation>&amp;Tipo de caractere da legenda ...</translation>
    </message>
    <message>
        <source>&amp;Dielectric constant</source>
        <translation>Constante &amp;dieléctrica</translation>
    </message>
    <message>
        <source>F&amp;requency</source>
        <translation>F&amp;requência</translation>
    </message>
    <message>
        <source>Line &amp;length</source>
        <translation>Comprimento da &amp;linha</translation>
    </message>
    <message>
        <source>Line &amp;width</source>
        <translation>Lar&amp;gura da linha</translation>
    </message>
    <message>
        <source>Elec&amp;trical length</source>
        <translation>Comprimento eléc&amp;trico</translation>
    </message>
    <message>
        <source>Line &amp;impedance</source>
        <translation>&amp;Impedância da Linha</translation>
    </message>
    <message>
        <source>&amp;Electrical</source>
        <translation>&amp;Eléctrico</translation>
    </message>
    <message>
        <source>&amp;Physical</source>
        <translation>&amp;Físico</translation>
    </message>
    <message>
        <source>degrees</source>
        <translation>graus</translation>
    </message>
    <message>
        <source>impedance</source>
        <translation>impedância</translation>
    </message>
    <message>
        <source>&amp;Substrate height</source>
        <translation>&amp;Espessura do substrato</translation>
    </message>
    <message>
        <source>Select Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New settings will take effect when ViPEC is restarted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>INDUCTORM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coupling factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CAPACITORQ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Primary inductance (L1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Secondary inductance (L2)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
