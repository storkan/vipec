<!DOCTYPE TS><TS>
<defaultcodec>iso8859-1</defaultcodec>
<context>
    <name>Strings</name>
    <message>
        <source>LanguageName</source>
        <translation type="unfinished">French</translation>
    </message>
    <message>
        <source>ViPEC</source>
        <translation>ViPEC</translation>
    </message>
    <message>
        <source>ViPEC online help</source>
        <translation>Aide en ligne ViPEC</translation>
    </message>
    <message>
        <source>Schematic name</source>
        <translation>Nom du schéma</translation>
    </message>
    <message>
        <source>About ViPEC</source>
        <translation>A propos de ViPEC</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>A propos de Qt</translation>
    </message>
    <message>
        <source>Add new variable</source>
        <translation>Ajouter une nouvelle variable</translation>
    </message>
    <message>
        <source>Modify frequency sweep</source>
        <translation>Changer le balayage fréquentiel</translation>
    </message>
    <message>
        <source>Modify grid</source>
        <translation>Changer la grille</translation>
    </message>
    <message>
        <source>Modify Smith chart</source>
        <translation>Changer l&apos;abaque de Smith</translation>
    </message>
    <message>
        <source>Change variable value</source>
        <translation>Changer la valeur de la variable</translation>
    </message>
    <message>
        <source>Rename variable</source>
        <translation>Renommer la variable</translation>
    </message>
    <message>
        <source>Rename substrate</source>
        <translation>Renommer le substrat</translation>
    </message>
    <message>
        <source>Change dimension value</source>
        <translation>Changer la valeur des dimensions</translation>
    </message>
    <message>
        <source>Edit component attributes</source>
        <translation>Editer les attributs du composant</translation>
    </message>
    <message>
        <source>Rename schematic</source>
        <translation>Renommer le schéma</translation>
    </message>
    <message>
        <source>Add new graph</source>
        <translation>Ajouter un nouveau graphe</translation>
    </message>
    <message>
        <source>Rename grid</source>
        <translation>Renommer la grille</translation>
    </message>
    <message>
        <source>Delete grid</source>
        <translation>Supprimer grille</translation>
    </message>
    <message>
        <source>Micro strip calculator</source>
        <translation>Calculateur de ligne Microstrip</translation>
    </message>
    <message>
        <source>Change schematic size</source>
        <translation>Changer la taille du schéma</translation>
    </message>
    <message>
        <source>Ready ...</source>
        <translation>Prèt ...</translation>
    </message>
    <message>
        <source>File saved</source>
        <translation>Fichier enregistré</translation>
    </message>
    <message>
        <source>File loaded</source>
        <translation>Fichier chargé</translation>
    </message>
    <message>
        <source>Checking schematic %1 ...</source>
        <translation>Vérification du schéma %1 ...</translation>
    </message>
    <message>
        <source>Calculating response of schematic %1 ...</source>
        <translation>Calcul de la réponse du schéma %1 ...</translation>
    </message>
    <message>
        <source>Frequency sweep done ...</source>
        <translation>Balayage fréquentiel effectué ...</translation>
    </message>
    <message>
        <source>All schematics passed checks ...</source>
        <translation>Tous les schémas sont corrects ...</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fichier</translation>
    </message>
    <message>
        <source>&amp;Open ...</source>
        <translation>&amp;Ouvrir ...</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Enregistrer</translation>
    </message>
    <message>
        <source>Save &amp;as ...</source>
        <translation>Enregistrer &amp;sous ...</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Fermer</translation>
    </message>
    <message>
        <source>&amp;New schematic ...</source>
        <translation>&amp;Nouveau schéma ...</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation>&amp;Imprimer</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <source>&amp;Controls</source>
        <translation>&amp;Contrôles</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Aide</translation>
    </message>
    <message>
        <source>&amp;Index</source>
        <translation>&amp;Index</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;A propos</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>A propos de &amp;Qt</translation>
    </message>
    <message>
        <source>&amp;New item...</source>
        <translation>&amp;Nouvel élément ...</translation>
    </message>
    <message>
        <source>&amp;Modify item ...</source>
        <translation>&amp;Modifier l&apos;élément ...</translation>
    </message>
    <message>
        <source>&amp;Rename item ...</source>
        <translation>&amp;Renommer l&apos;élément ...</translation>
    </message>
    <message>
        <source>&amp;Delete item</source>
        <translation>&amp;Supprimer l&apos;élément</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>&amp;Outils</translation>
    </message>
    <message>
        <source>&amp;Micro strip calculator ...</source>
        <translation>&amp;Calculateur de ligne microstrip ...</translation>
    </message>
    <message>
        <source>&amp;Tuner ...</source>
        <translation>&amp;Régler ...</translation>
    </message>
    <message>
        <source>Your current changes are not saved! Do you wish to continue?</source>
        <translation>Vos modifications ne sont pas sauvegardées! Voulez-vous continuer?</translation>
    </message>
    <message>
        <source>Could not write file!</source>
        <translation>Ecriture du fichier impossible!</translation>
    </message>
    <message>
        <source>Could not open file!</source>
        <translation>Ouverture du fichier impossible!</translation>
    </message>
    <message>
        <source>Please enter a name for the schematic</source>
        <translation>Entrez un nom pour le schéma</translation>
    </message>
    <message>
        <source>A schematic with that name already exists!</source>
        <translation>Un schéma avec ce nom existe déja!</translation>
    </message>
    <message>
        <source>Please enter a name for the new variable</source>
        <translation>Entrez un nom pour la nouvelle variable</translation>
    </message>
    <message>
        <source>A variable with that name already exists!</source>
        <translation>Une variable avec ce nom existe déja!</translation>
    </message>
    <message>
        <source>Please enter a value for the new variable</source>
        <translation>Entrez une valeur pour la nouvelle variable</translation>
    </message>
    <message>
        <source>Please enter a new value for the variable named %1</source>
        <translation>Entrez une nouvelle valeur pour la variable appelée %1</translation>
    </message>
    <message>
        <source>Please enter a new name for the variable named %1</source>
        <translation>Entrez un nouveau nom pour la variable appelée %1</translation>
    </message>
    <message>
        <source>Do you really want to remove the variable named %1?</source>
        <translation>Voulez-vous réellement supprimer la variable appelée %1?</translation>
    </message>
    <message>
        <source>Please enter a new name for the substrate named %1</source>
        <translation>Entrez un nouveau nom pour le substrat appelé %1</translation>
    </message>
    <message>
        <source>Do you really want to remove the substrate named %1?</source>
        <translation>Voulez-vous réellement supprimer le substrat appelé %1?</translation>
    </message>
    <message>
        <source>There are some floating nodes!</source>
        <translation>Il y a des noeuds flottants!</translation>
    </message>
    <message>
        <source>Some port nodes are shorted together!</source>
        <translation>Des noeuds du port sont reliés ensemble!</translation>
    </message>
    <message>
        <source>Please enter a new name for the schematic named %1</source>
        <translation>Entrez un nouveau nom pour le schéma appelé %1</translation>
    </message>
    <message>
        <source>Do you really want to remove the schematic named %1?</source>
        <translation>Voulez-vous réellement supprimer le schéma appelé %1?</translation>
    </message>
    <message>
        <source>Please enter a name for the graph</source>
        <translation>Entrez un nom pour le graphe</translation>
    </message>
    <message>
        <source>Please enter a new name for the graph named %1</source>
        <translation>Entrez un nouveau nom pour le graphe appelé %1</translation>
    </message>
    <message>
        <source>A graph with the name %1 already exists!</source>
        <translation>Un graphe appelé %1 existe déja!</translation>
    </message>
    <message>
        <source>Do you really want to remove the graph named %1?</source>
        <translation>Voulez-vous réellement supprimer le graphe appelé %1?</translation>
    </message>
    <message>
        <source>There are no schematics defined!</source>
        <translation>Aucun schéma défini!</translation>
    </message>
    <message>
        <source>There are no range variables defined!</source>
        <translation>Aucune variable variation définie!</translation>
    </message>
    <message>
        <source>Circuit files (*.ckt)</source>
        <translation>Fichiers circuit (*.ckt)</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Oui</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Abandonner</translation>
    </message>
    <message>
        <source>&amp;Sweep</source>
        <translation>&amp;Balayer</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Petit</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Moyen</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Grand</translation>
    </message>
    <message>
        <source>Navigation</source>
        <translation>Navigation</translation>
    </message>
    <message>
        <source>Graph name</source>
        <translation>Nom du graphe</translation>
    </message>
    <message>
        <source>Graph type</source>
        <translation>Type du graphe</translation>
    </message>
    <message>
        <source>Rectangular</source>
        <translation>Rectangulaire</translation>
    </message>
    <message>
        <source>Smith chart</source>
        <translation>Abaque de Smith</translation>
    </message>
    <message>
        <source>Table</source>
        <translation>Table</translation>
    </message>
    <message>
        <source>Grid title</source>
        <translation>Titre de la grille</translation>
    </message>
    <message>
        <source>Smith chart title</source>
        <translation>Titre de l&apos;abaque de Smith</translation>
    </message>
    <message>
        <source>Minimum X axis value</source>
        <translation>Valeur minimum axe X</translation>
    </message>
    <message>
        <source>Maximum X axis value</source>
        <translation>Valeur maximum axe X</translation>
    </message>
    <message>
        <source>Number of X axis ticks</source>
        <translation>Nombre de marques sur l&apos;axe X</translation>
    </message>
    <message>
        <source>Minimum Y axis value</source>
        <translation>Valeur minimum axe Y</translation>
    </message>
    <message>
        <source>Maximum Y axis value</source>
        <translation>Valeur maximum axe Y</translation>
    </message>
    <message>
        <source>Number of Y axis ticks</source>
        <translation>Nombre de marques sur l&apos;axe Y</translation>
    </message>
    <message>
        <source>Port parameters</source>
        <translation>Paramètres du port</translation>
    </message>
    <message>
        <source>Linvill stability factor</source>
        <translation>Facteur de stabilité de Linvill</translation>
    </message>
    <message>
        <source>Stern stability factor</source>
        <translation>Facteur de stabilité de Stern</translation>
    </message>
    <message>
        <source>S-Parameters</source>
        <translation>Paramètres S</translation>
    </message>
    <message>
        <source>Y-Parameters</source>
        <translation>Paramètres Y</translation>
    </message>
    <message>
        <source>Z-Parameters</source>
        <translation>Paramètres Z</translation>
    </message>
    <message>
        <source>Group delay</source>
        <translation>Délai de groupe</translation>
    </message>
    <message>
        <source>Measurement type</source>
        <translation>Type de mesure</translation>
    </message>
    <message>
        <source>Measurement</source>
        <translation>Mesure</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Real</source>
        <translation>Réel</translation>
    </message>
    <message>
        <source>Imag</source>
        <translation>Imag</translation>
    </message>
    <message>
        <source>Mag</source>
        <translation>Mod</translation>
    </message>
    <message>
        <source>Ang</source>
        <translation>Arg</translation>
    </message>
    <message>
        <source>Results in DB</source>
        <translation>Résultat en dB</translation>
    </message>
    <message>
        <source>Data source</source>
        <translation>Fichier source</translation>
    </message>
    <message>
        <source>To port</source>
        <translation>Vers le port</translation>
    </message>
    <message>
        <source>From port</source>
        <translation>Du port</translation>
    </message>
    <message>
        <source>X-axis tracks project frequency</source>
        <translation>L&apos;axe X suit la fréquence du projet</translation>
    </message>
    <message>
        <source>Auto sweep</source>
        <translation>Balayage automatique</translation>
    </message>
    <message>
        <source>Substrate name</source>
        <translation>Nom du substrat</translation>
    </message>
    <message>
        <source>Substrate type</source>
        <translation>Type du substrat</translation>
    </message>
    <message>
        <source>Microstrip</source>
        <translation>Microstrip</translation>
    </message>
    <message>
        <source>Stripline</source>
        <translation>Ligne strip</translation>
    </message>
    <message>
        <source>Dielectric constant (Er)</source>
        <translation>Constante diélectrique (Er)</translation>
    </message>
    <message>
        <source>Height (H)</source>
        <translation>Hauteur (H)</translation>
    </message>
    <message>
        <source>Conductor thickness (T)</source>
        <translation>Epaisseur du conducteur (T)</translation>
    </message>
    <message>
        <source>Loss tangent (rho)</source>
        <translation>Tangente de perte (rho)</translation>
    </message>
    <message>
        <source>Schematic size</source>
        <translation>Taille du schéma</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Ouvrir le fichier</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation>Enregistrer le fichier</translation>
    </message>
    <message>
        <source>New schematic</source>
        <translation>Nouveau schéma</translation>
    </message>
    <message>
        <source>Place symbol</source>
        <translation>Placer le symbol</translation>
    </message>
    <message>
        <source>Connect symbols</source>
        <translation>Relier les symboles</translation>
    </message>
    <message>
        <source>Toggle grid</source>
        <translation>Afficher la grille</translation>
    </message>
    <message>
        <source>Toggle component text</source>
        <translation>Afficher le texte du composant</translation>
    </message>
    <message>
        <source>Rotate symbol</source>
        <translation>Tourner le symbol</translation>
    </message>
    <message>
        <source>Sweep</source>
        <translation>Balayage</translation>
    </message>
    <message>
        <source>Delete symbol</source>
        <translation>Supprimer l&apos;élément</translation>
    </message>
    <message>
        <source>Port components</source>
        <translation>Composants port</translation>
    </message>
    <message>
        <source>Block components</source>
        <translation>Composants bloc</translation>
    </message>
    <message>
        <source>Lumped components</source>
        <translation>Composants de bases</translation>
    </message>
    <message>
        <source>Transmission line components</source>
        <translation>Composants ligne de transmission</translation>
    </message>
    <message>
        <source>VCCS</source>
        <translation>VCCS</translation>
    </message>
    <message>
        <source>GYRATOR</source>
        <translation>GIRATEUR</translation>
    </message>
    <message>
        <source>RESISTOR</source>
        <translation>RESISTANCE</translation>
    </message>
    <message>
        <source>CAPACITOR</source>
        <translation>CAPACITE</translation>
    </message>
    <message>
        <source>INDUCTOR</source>
        <translation>INDUCTANCE</translation>
    </message>
    <message>
        <source>INDUCTORQ</source>
        <translation>INDUCTANCEQ</translation>
    </message>
    <message>
        <source>TRANSISTOR</source>
        <translation>TRANSISTOR</translation>
    </message>
    <message>
        <source>TLIN2PORT</source>
        <translation>TLIN2PORT</translation>
    </message>
    <message>
        <source>TLIN4PORT</source>
        <translation>TLIN4PORT</translation>
    </message>
    <message>
        <source>TLINPHYSICAL</source>
        <translation>TLINPHYSICAL</translation>
    </message>
    <message>
        <source>CLIN</source>
        <translation>CLIN</translation>
    </message>
    <message>
        <source>GND</source>
        <translation>GND</translation>
    </message>
    <message>
        <source>PORT</source>
        <translation>PORT</translation>
    </message>
    <message>
        <source>BLOCK1PORT</source>
        <translation>BLOC1PORT</translation>
    </message>
    <message>
        <source>BLOCK2PORT</source>
        <translation>BLOC2PORT</translation>
    </message>
    <message>
        <source>Schematics</source>
        <translation>Schémas</translation>
    </message>
    <message>
        <source>Project frequencies</source>
        <translation>Fréquences du projet</translation>
    </message>
    <message>
        <source>Graphs</source>
        <translation>Graphes</translation>
    </message>
    <message>
        <source>Variables</source>
        <translation>Variables</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Unités</translation>
    </message>
    <message>
        <source>Substrate definitions</source>
        <translation>Définitions du substrat</translation>
    </message>
    <message>
        <source>Data files</source>
        <translation>Fichier de données</translation>
    </message>
    <message>
        <source>noname.ckt</source>
        <translation>noname.ckt</translation>
    </message>
    <message>
        <source>Sweep type</source>
        <translation>Type de balayage</translation>
    </message>
    <message>
        <source>Linear</source>
        <translation>Linéaire</translation>
    </message>
    <message>
        <source>Logarithmic</source>
        <translation>Logarithmique</translation>
    </message>
    <message>
        <source>Start frequency</source>
        <translation>Fréquence de départ</translation>
    </message>
    <message>
        <source>Stop frequency</source>
        <translation>Fréquence de fin</translation>
    </message>
    <message>
        <source>Number of points</source>
        <translation>Nombre de points</translation>
    </message>
    <message>
        <source>Frequency</source>
        <translation>Fréquence</translation>
    </message>
    <message>
        <source>Resistance</source>
        <translation>Résistance</translation>
    </message>
    <message>
        <source>Capacitance</source>
        <translation>Capacité</translation>
    </message>
    <message>
        <source>Inductance</source>
        <translation>Inductance</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation>Angle</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Longueur</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Temps</translation>
    </message>
    <message>
        <source>Impedance</source>
        <translation>Impédance</translation>
    </message>
    <message>
        <source>Odd mode impedance</source>
        <translation>Impédance mode impair</translation>
    </message>
    <message>
        <source>Even mode impedance</source>
        <translation>Impédance mode pair</translation>
    </message>
    <message>
        <source>Electrical length in degrees</source>
        <translation>Longueur électrique en degrées</translation>
    </message>
    <message>
        <source>Frequency at which electrical length is defined</source>
        <translation>Fréquence pour laquelle la longueur électrique est donnée</translation>
    </message>
    <message>
        <source>Substrate</source>
        <translation>Substrat</translation>
    </message>
    <message>
        <source>Port impedance</source>
        <translation>Impédance du port</translation>
    </message>
    <message>
        <source>Block name</source>
        <translation>Nom du bloc</translation>
    </message>
    <message>
        <source>Quality factor</source>
        <translation>Facteur de qualité</translation>
    </message>
    <message>
        <source>Trans conductance</source>
        <translation>Transconductance</translation>
    </message>
    <message>
        <source>Gyrator factor</source>
        <translation>Facteur de giration</translation>
    </message>
    <message>
        <source>Line width</source>
        <translation>Largeur de la ligne</translation>
    </message>
    <message>
        <source>Line length</source>
        <translation>Longueur de la ligne</translation>
    </message>
    <message>
        <source>Circuit tuner</source>
        <translation>Régleur de circuit</translation>
    </message>
    <message>
        <source>Define substrate</source>
        <translation>Définir le substrat</translation>
    </message>
    <message>
        <source>Missing attribute value in circuit %1!</source>
        <translation>Il manque une valeur de paramètre dans le circuit %1!</translation>
    </message>
    <message>
        <source>Undefined variable in cicuit %1!</source>
        <translation>Variable non-définie dans le circuit %1!</translation>
    </message>
    <message>
        <source>Variable used in circuit %1 has no value!</source>
        <translation>La variable utilisée dans le circuit %1 n&apos;a pas de valeur!</translation>
    </message>
    <message>
        <source>Undefined substrate in circuit %1!</source>
        <translation>Substrat non-défini dans le circuit %1!</translation>
    </message>
    <message>
        <source>Unknown exception!!!</source>
        <translation>Exception inconnue!!!</translation>
    </message>
    <message>
        <source>The output definitions contains an invalid circuit name!</source>
        <translation>Les définitions de  sortie contiennent un nom de circuit invalide!</translation>
    </message>
    <message>
        <source>Stability factors are only defined for 2 port circuits!</source>
        <translation>Les facteurs de stabilités ne sont définis que pour les circuits 2 ports!</translation>
    </message>
    <message>
        <source>Singular matrix - no solution possible!</source>
        <translation>Matrice singulière - pas de solution possible!</translation>
    </message>
    <message>
        <source>The number of ports are not matched!</source>
        <translation>Les numéros de ports ne correspondent pas!</translation>
    </message>
    <message>
        <source>Undefined block in circuit %1!</source>
        <translation>Bloc non défini dans le circuit %1!</translation>
    </message>
    <message>
        <source>Sweep frequency beyond limits of block data in circuit %1</source>
        <translation>La fréquence de balayage est en dehors des limites du bloc de données dans le circuit %1</translation>
    </message>
    <message>
        <source>Parameter files (*.?2p)</source>
        <translation>Fichier paramètre (*.?2p)</translation>
    </message>
    <message>
        <source>Output parameter definition</source>
        <translation>Définition du paramètre de sortie</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Visualiser</translation>
    </message>
    <message>
        <source>&amp;Refresh</source>
        <translation>&amp;Rafraichir</translation>
    </message>
    <message>
        <source>&amp;Markers</source>
        <translation>&amp;Marqueurs</translation>
    </message>
    <message>
        <source>&amp;Toggle</source>
        <translation>&amp;Afficher</translation>
    </message>
    <message>
        <source>&amp;Fonts</source>
        <translation>&amp;Polices</translation>
    </message>
    <message>
        <source>&amp;Title font ...</source>
        <translation>&amp;Police de caractère du titre ...</translation>
    </message>
    <message>
        <source>&amp;Label font ...</source>
        <translation>&amp;Police de caractère du label ...</translation>
    </message>
    <message>
        <source>&amp;Dielectric constant</source>
        <translation>Constante &amp;diélectrique</translation>
    </message>
    <message>
        <source>F&amp;requency</source>
        <translation>F&amp;réquence</translation>
    </message>
    <message>
        <source>Line &amp;length</source>
        <translation>Longueur de la &amp;ligne</translation>
    </message>
    <message>
        <source>Line &amp;width</source>
        <translation>Lar&amp;geur de la ligne</translation>
    </message>
    <message>
        <source>Elec&amp;trical length</source>
        <translation>Longueur élec&amp;trique</translation>
    </message>
    <message>
        <source>Line &amp;impedance</source>
        <translation>&amp;Impédance de la ligne</translation>
    </message>
    <message>
        <source>&amp;Electrical</source>
        <translation>&amp;Electrique</translation>
    </message>
    <message>
        <source>&amp;Physical</source>
        <translation>&amp;Physique</translation>
    </message>
    <message>
        <source>degrees</source>
        <translation>degrées</translation>
    </message>
    <message>
        <source>impedance</source>
        <translation>impédance</translation>
    </message>
    <message>
        <source>&amp;Substrate height</source>
        <translation>&amp;Hauteur du substrat</translation>
    </message>
    <message>
        <source>Select Language</source>
        <translation>Sélectionnez la langue</translation>
    </message>
    <message>
        <source>&amp;Setup</source>
        <translation>&amp;Configuration</translation>
    </message>
    <message>
        <source>&amp;Language</source>
        <translation>&amp;Langue</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Langue</translation>
    </message>
    <message>
        <source>New settings will take effect when ViPEC is restarted</source>
        <translation>Les nouveaux réglages prendront effet après redémarrage de ViPEC</translation>
    </message>
    <message>
        <source>INDUCTORM</source>
        <translation>INDUCTORM</translation>
    </message>
    <message>
        <source>Coupling factor</source>
        <translation>Facteur de couplage</translation>
    </message>
    <message>
        <source>CAPACITORQ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Primary inductance (L1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Secondary inductance (L2)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
